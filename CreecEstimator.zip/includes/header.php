<header class="jscontent" style="display: none;">
    <div class="burger">
        <div class="bar"></div>
        <div class="bar"></div>
        <div class="bar"></div>
    </div>
    <div id="home">
        <a href="/portfolio/creec/">
            <p>C</p>
            <p>R</p>
            <p>E</p>
            <p>E</p>
            <p>C</p>
        </a>
    </div>
</header>
<div id="navigation-wrapper" class="jscontent" style="display:none;">
    <nav id="navigation" class="swipe">
        <ul id="menu">
            <li id="estimator" class="nav-item"><a href="/portfolio/creec">Estimator</a></li>
            <li class="nav-item"><a href="/portfolio/creec/about">About</a></li>
            <li class="nav-item"><a href="/portfolio/creec/contact">Contact</a></li>
        </ul>
    </nav>
</div>

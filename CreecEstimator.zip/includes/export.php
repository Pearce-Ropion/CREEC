<link rel="stylesheet" href="/portfolio/creec/assets/styles/print.min.css" />
<script type="text/javascript" src="/portfolio/creec/assets/scripts/libs/FileSaver/FileSaver.min.js"></script>
<script type="text/javascript" src="/portfolio/creec/assets/scripts/libs/js-xlsx/xlsx.core.min.js"></script>
<script type="text/javascript" src="/portfolio/creec/assets/scripts/libs/jsPDF/jspdf.min.js"></script>
<script type="text/javascript" src="/portfolio/creec/assets/scripts/libs/jsPDF-AutoTable/jspdf.plugin.autotable.js"></script>
<script type="text/javascript" src="/portfolio/creec/assets/scripts/libs/html2canvas/html2canvas.min.js"></script>
<script type="text/javascript" src="/portfolio/creec/assets/scripts/tableExport.min.js"></script>
<script type="text/javascript" src="/portfolio/creec/assets/scripts/print.min.js"></script>
